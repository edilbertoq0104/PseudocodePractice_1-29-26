import sys
import pygame
import random


#Loading Music/SFX
from pygame import mixer

pygame.init()

width = 800
height = 600
size = (width, height)
black = (0,0,0)
screen = pygame.display.set_mode(size)
pygame.display.set_caption("Chicken Click Game")

chicken = pygame.image.load("chicken.png")
power = pygame.image.load("snail.png")

#Background
background = pygame.image.load("bg.png")

iterator = 0
numofchickens = 5
startX = []
startY = []
speed = []

while iterator < numofchickens:
  startX.append(random.randint(0, width - chicken.get_width() + 1))
  startY.append(0 - random.randint(chicken.get_height(), chicken.get_height() * 2))
  speed.append(0.5)
  iterator += 1

replayscreen = False
#Set up game over stuff

bigfont = pygame.font.SysFont(None, 200)
playagaintext = bigfont.render("Play Again?", True, (0,200,0))
pax = width/2 - playagaintext.get_rect().width/2

smallfont = pygame.font.SysFont(None, 100)
yestext = smallfont.render("YES", True, (0, 200, 0))
yesx = width/4 - yestext.get_rect().width/2
notext = smallfont.render("NO", True, (0,200,0))
nox = width - width/4 - yestext.get_rect().width/2

#Game Loop

gameover = False

#Music
mixer.music.load('bgm.ogg')
mixer.music.play(-1)

while gameover == False:
  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      gameover = True

    #Power Up
    powerX = random.randint(0, width - power.get_width())
    powerY = random.randint(0, height - power.get_height())
    power_active = True  

  #Clicking on the Chickens
  if pygame.mouse.get_pressed()[0]:
    coords = pygame.mouse.get_pos()
    if replayscreen == False:
      iterator = 0
      while iterator < numofchickens:
        if coords[0] >= startX[iterator] and coords[0] <= startX[iterator] + chicken.get_width() and coords[1] > startY[iterator] and coords[1] < startY[iterator] + chicken.get_height():
          startX[iterator] =  random.randint(0, width - chicken.get_width() + 1)
          startY[iterator] = 0 - random.randint(chicken.get_height(), chicken.get_height() * 2)
          speed[iterator] = 0.5
          die_Sound = mixer.Sound('click.mp3')
          die_Sound.play()
          break

        iterator += 1

        if power and (powerX <= coords[0] <= powerX + power.get_width() and powerY <= coords[1] <= powerY + power.get_height()):
          power_active = False
    else:
      if coords[0] > yesx and coords[0] < yesx + yestext.get_rect().width and coords[1] > 450 and coords[1] < 450 + yestext.get_rect().height:
        iterator = 0
        while iterator < numofchickens:
          startX[iterator] =  random.randint(0, width - chicken.get_width() + 1)
          startY[iterator] = 0 - random.randint(chicken.get_height(), chicken.get_height() * 2)
          speed[iterator] = 0.5
          iterator +=1
        replayscreen = False

      if coords[0] > nox and coords[0] < nox + notext.get_rect().width and coords[1] > 450 and coords[1] < 450 + notext.get_rect().height:
        gameover = True

  #Updating
  if replayscreen == False:
    iterator = 0
    #Game over
    while iterator < numofchickens:
      if startY[iterator] + chicken.get_height() > height:
        replayscreen = True
        break
      startY[iterator] += speed[iterator]
      iterator += 1


  #Drawing

  if replayscreen == False:
    screen.fill(black)
    screen.blit(background, (0,0))

    iterator = 0
    while iterator < numofchickens:
      screen.blit(chicken, (startX[iterator], startY[iterator]))
      iterator += 1

    iterator = 0

    if power_active:
      screen.blit(power, (powerX, powerY))

  else:
    screen.fill((200,0,0))

    screen.blit(playagaintext, (pax, 150))
    screen.blit(yestext, (yesx, 450))
    screen.blit(notext, (nox, 450))

  pygame.display.flip()

pygame.display.quit()